copy to .local/share/code-server/User/settings.json
 