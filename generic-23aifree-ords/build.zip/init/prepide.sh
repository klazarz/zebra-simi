#!/bin/bash

# use this script to copy everything you want to have access to in JupyterLab to /home/opc/compose2cloud/composescript/envvar

cp -r /home/opc/compose2cloud/composescript/app/simidemo/ /home/opc/compose2cloud/composescript/envvar/